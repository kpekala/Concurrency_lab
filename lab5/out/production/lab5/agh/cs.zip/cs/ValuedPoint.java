package agh.cs;

public class ValuedPoint {
    int x;
    int y;
    int value;
    public ValuedPoint(int x, int y, int value){
        this.x = x;
        this.y = y;
        this.value = value;
    }
}
